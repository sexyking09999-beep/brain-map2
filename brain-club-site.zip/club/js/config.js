// 깃허브 저장소 정보 (본인 것으로 바꾸세요) 예: "myclub/brain-map"
var SITE={github:"내아이디/저장소이름",branch:"main"};
